#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v ffmpeg >/dev/null || ! command -v ffprobe >/dev/null; then
  echo 'Cần FFmpeg. Nếu đã có Homebrew, chạy: brew install ffmpeg'
  read -r -p 'Nhấn Enter để đóng.' _answer
  exit 1
fi
if ! command -v python3 >/dev/null; then
  echo 'Cần Python 3.12 trở lên: https://www.python.org/downloads/macos/'
  exit 1
fi
python3 -c 'import sys; assert sys.version_info >= (3,12), "Cần Python 3.12 trở lên"'
read -r -p 'Kéo MOV gốc từ Finder vào đây rồi nhấn Enter: ' video_input
read -r -p 'Kéo thư mục CAPCUT_PREMIUM_EDIT_PACK vào đây rồi nhấn Enter: ' pack_input
# Finder drag-and-drop paths use shell backslash escaping. shlex parses paths
# without evaluating shell code or command substitutions.
video_path=$(python3 -c 'import shlex,sys; v=shlex.split(sys.argv[1]); assert len(v)==1; print(v[0])' "$video_input")
pack_path=$(python3 -c 'import shlex,sys; v=shlex.split(sys.argv[1]); assert len(v)==1; print(v[0])' "$pack_input")
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
render_target="../FULL_RES_EDIT_$(date +%Y%m%d_%H%M%S)"
.venv/bin/python render_source_edit.py "$video_path" --pack "$pack_path" --output "$render_target" --width 1080
echo "Đã xuất: $render_target/HOANG_TAN_PHAT_AUTO_EDIT.mp4"
read -r -p 'Nhấn Enter để đóng.' _answer
