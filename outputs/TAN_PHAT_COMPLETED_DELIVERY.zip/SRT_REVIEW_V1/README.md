# Rà soát SRT — bản nháp chỉ đối chiếu văn bản

SRT nguồn có 111 đoạn, kết thúc 05:14.166. SOURCE_ORIGINAL.srt giữ nguyên từng byte. HOANG_DRAMA_TEXT_REVIEW_DRAFT.srt giữ nguyên timestamp, chuẩn hóa Unicode, sửa chữ hoa và lỗi rõ theo ngữ cảnh (máy rửa 8 → máy rửa bát; lau rẻ → lau giẻ). Chưa nghe âm thanh nên chưa phải phụ đề cuối.

Không tự sửa inox/INAX, boss/Bosch, cáp/KAFF, Roblox, quevo Pro 2, ecovac hoặc đơn vị lực hút. Xem SUBTITLE_REVIEW_ISSUES.csv để kiểm chứng tên hãng, model, địa phương, con số, tuyên bố độc quyền và so sánh hiệu năng. Những từ chưa xác minh còn nguyên trong SRT nháp; không dùng làm phụ đề xuất bản trước khi duyệt.

TIMELINE_SRT_ALIGNMENT.csv đối chiếu 74 cue với timestamp SRT, không chứng minh callout khớp ý hay khớp âm thanh. SFX_TIMELINE_SRT_LENGTH.wav nối im lặng vào bản 314 giây để có độ dài 314,166 giây theo SRT; không tuyên bố video có cùng độ dài.

MOV tải lên vượt giới hạn chuyển 32 MiB của công cụ; chưa đọc hình/âm thanh, chưa xác minh tỷ lệ hay vùng an toàn. Cần MP4 proxy dưới 32 MiB, giữ nguyên toàn bộ thời lượng, điểm bắt đầu và âm thanh. Không tăng tốc hoặc cắt đoạn. Ví dụ FFmpeg trên máy có video:

ffmpeg -i "hoàng hút bụi drama.mov" -vf "scale=640:640:force_original_aspect_ratio=decrease:force_divisible_by=2" -c:v libx264 -preset medium -b:v 450k -maxrate 500k -bufsize 1000k -pix_fmt yuv420p -c:a aac -b:a 64k -movflags +faststart "hoang_drama_proxy.mp4"

Với thời lượng khoảng 314 giây, bitrate này thường cho tệp khoảng 21 MB. Kiểm tra dung lượng thực tế trước khi tải lên. Giữ MOV gốc trên máy để xuất cuối ở chất lượng gốc.
