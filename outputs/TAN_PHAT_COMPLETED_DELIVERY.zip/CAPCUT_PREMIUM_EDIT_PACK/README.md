# TẤN PHÁT PREMIUM CAPCUT PACK — BẢN NHÁP TÀI NGUYÊN

40 SFX tổng hợp nhiều lớp; 48 kHz PCM 16-bit; 2 giây im lặng giữa 40 SFX trong SFX_PREVIEW.wav. SFX_TIMELINE.wav dài 314 giây, có thể đặt tại 00:00 trên một track âm thanh riêng. Gain cue đã giảm nhưng chưa thể cân với giọng nói vì thiếu MOV.

74 cue theo mốc người dùng cung cấp (73 text + 1 audio), chưa xác minh bằng MOV/SRT. Không có phụ đề lời thoại đã rà soát. Không có logo chính thức: chữ TẤN PHÁT chỉ là wordmark minh họa. Không xác minh tên model, thông số, thương hiệu hoặc tuyên bố quảng cáo.

30 preset là cấu hình JSON + MOV mẫu, không phải preset CapCut native. Mỗi câu callout có PNG RGBA và MOV alpha riêng. MOV dùng QuickTime Animation qtrle/argb, 960×540, 24 fps, alpha thực. Khả năng import qtrle phụ thuộc phiên bản CapCut; dùng PNG kèm keyframe JSON nếu không hỗ trợ. Không chuyển MP4 preview thành overlay vì MP4 không có alpha.

## Nhập CapCut
1. Giải nén ZIP vào máy tính. Import WAV, PNG và MOV cần dùng.
2. Đặt video nguồn trên track chính; SFX_TIMELINE.wav tại 00:00. Không import SFX_PREVIEW.wav như soundtrack.
3. Tham khảo 06_TIMELINE/timeline.csv để đặt từng MOV/PNG lên track overlay. CSV/JSON là cue sheet tham khảo, không tự tạo project CapCut.
4. Kiểm tra tỉ lệ nguồn, dời chữ tránh mặt/sản phẩm và đồng bộ lại từng cue. Canvas 16:9 chỉ là bố cục tạm, không khẳng định video nguồn 16:9.
5. Preview MP4 dùng nền đồ họa minh họa, không chứa video nguồn. Đây chưa phải bản dựng cuối.

## Tái tạo bằng mã nguồn
Từ repository: .venv/bin/python src/premium_pack.py --output outputs/TEN_THU_MUC_MOI
Từ 08_SOURCE_CODE: cài requirements.txt, đặt NotoSans-Bold.ttf vào đường dẫn --font hoặc dùng font mặc định hệ thống; chạy python premium_pack.py --output ../TEN_THU_MUC_MOI. FFmpeg và FFprobe phải có trong PATH.
Chương trình từ chối ghi đè thư mục output và ZIP đã có. Bộ WAV và ZIP trước đó được giữ nguyên.

Cần cung cấp hoàng hút bụi drama.mov và hoàng hút bụi drama(1).srt để hoàn thiện phụ đề, xác minh tuyên bố sản phẩm và dựng preview trên hình thật.
